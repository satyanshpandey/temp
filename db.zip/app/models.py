import uuid
from django.db import models



class ParentClass(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=100)
    class Meta:
        abstract = True


# Create your models here.
class Employee(ParentClass):
    email = models.EmailField(unique=True)
    position = models.CharField(max_length=100)
    def __str__(self):
        return self.name
    
class Student(models.Model):
    primarykey = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=111)
    def __str__(self):
        return self.name 
    