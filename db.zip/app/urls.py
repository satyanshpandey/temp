

from django.urls import path
from . import views
from django.contrib.auth.models import User
urlpatterns = [
    path('' , views.employeeListView, name='employee-list'),

    path('users' ,views.userlistview),
]