from django.shortcuts import render
from django.http import JsonResponse
from .models import Employee
from .serializers import EmployeeSerializer
from django.contrib.auth.models import User
from django.http import HttpResponse as https
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
import logging

# Set up logger for this module
logger = logging.getLogger(__name__)
# Create your views here.
@csrf_exempt  # Use this decorator if you want to allow POST requests without CSRF token
def employeeListView(request):
    if request.method == 'GET':
        ob1 = Employee.objects.all()
        serializerrr = EmployeeSerializer(ob1, many=True)
        # print("serialized data: ",serializerrr.data)
        for i in serializerrr.data:
            print("serialized data: ", i,"\n\n")
        return JsonResponse(serializerrr.data, safe=False)
        # return JsonResponse({"message": "List of employees"})
    elif request.method == 'POST':
        jsonData = JSONParser().parse(request)
        serializerr = EmployeeSerializer(data = jsonData)
        if serializerr.is_valid():
            serializerr.save()
            logger.info("New employee created successfully: %s", serializerr.data)
            print("New employee created successfully: ", serializerr.data)
            return JsonResponse({'message': 'New employee created successfully.'} , safe=False)
        else:
            print("Error: ", serializerr.errors)
            logger.error("Failed to create new employee: %s", serializerr.errors)
        return JsonResponse({'message': 'Failed to create new employee.','errors': serializerr.errors} , safe=False)

def userlistview(request):
    print("@"*33 , "\n user list view called method")
    userss = User.objects.all().values('id', 'username', 'email', 'first_name', 'last_name')
    users_list = list(userss)
    return JsonResponse(users_list, safe=False)