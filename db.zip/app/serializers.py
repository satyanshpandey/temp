

from .models import Employee , Student
from rest_framework import serializers

class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = ['id', 'name', 'email', 'position']
        read_only_fields = ['id']  # id is auto-generated and should not be editable

        def create(self, validated_data):
            print("*"*33, "Create methods called")
            return Employee.objects.create(**validated_data)
        

class StudentSerializer(serializers.Serializer):
    primarykey = serializers.IntegerField(read_only=True)
    name = serializers.CharField(max_length=111)
    def create(self, validated_data):
        return Student.objects.create(**validated_data)